package com.example.blacktiger.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.blacktiger.HomeActivity;
import com.example.blacktiger.R;


/**
 * 登录
 */
public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button buttonLogin = (Button)this.findViewById(R.id.buttonLogin);
        buttonLogin.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                login();
            }
        });

        TextView textViewRegister = (TextView)this.findViewById(R.id.textViewRegister);
        textViewRegister.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoRegister();
            }
        });

        SharedPreferences sp = this.getSharedPreferences("tinyaccount", Context.MODE_PRIVATE);
        String name = sp.getString("name",null);
        EditText editTextName = findViewById(R.id.editTextName);
        editTextName.setText(name);

        TextView textViewNoPwd = (TextView)this.findViewById(R.id.textViewNoPwd);
        textViewNoPwd.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                promptPassword();
            }
        });

        EditText editTextPassword = findViewById(R.id.editTextPassword);
        editTextPassword.requestFocus();
    }

    private void promptPassword() {
        SharedPreferences sp = this.getSharedPreferences("tinyaccount", Context.MODE_PRIVATE);
        String prompt = sp.getString("prompt",null);
        if (prompt == null){
            prompt = "您没有设定密码提示.";
        }else{
            prompt = "您设定的密码提示为：" + prompt;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.delete_confirm_title);
        builder.setMessage(prompt);

        builder.setPositiveButton(R.string.button_ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    //注册
    private void gotoRegister() {
        Intent intent = new Intent(this,RegisterActivity.class);
        startActivity(intent);
    }

    //登录
    private void login() {
        EditText editTextPassword = findViewById(R.id.editTextPassword);
        String inputPassword = editTextPassword.getText().toString();
        SharedPreferences sp = this.getSharedPreferences("tinyaccount", Context.MODE_PRIVATE);
        String password = sp.getString("password",null);
        if (password == null || !inputPassword.equals(password)){
            Toast.makeText(this,"密码错误.",Toast.LENGTH_LONG).show();
        }else {
            this.finish();;
            Intent intent = new Intent(this, HomeActivity.class);
            startActivity(intent);
        }
    }


}

